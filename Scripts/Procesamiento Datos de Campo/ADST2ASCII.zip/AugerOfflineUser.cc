void
AugerOfflineUser()
{
}
